<?php
header("location: ../../");
die();

?>

