
<!DOCTYPE html>
<!--[if IEMobile 7 ]><html class="iem7 old no-js"><![endif]-->
<!--[if lt IE 7 ]><html lang="en" class="ie6 old no-js"><![endif]-->
<!--[if IE 7 ]><html lang="en" class="ie7 old no-js"><![endif]-->
<!--[if IE 8 ]><html lang="en" class="ie8 no-js"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="ie9 no-js"><![endif]-->
<!--[if (gte IE 9)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<!-- Mirrored from airdriesavingsbank.com/disclosure-personal-information-statements/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 09 Jul 2016 12:02:16 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8" />
    

<title>Disclosure Personal Information Statements : Airdrie Savings Bank</title>

<meta name="description" content="Discover Britain&#39;s only independent savings bank, with current and savings accounts for businesses and individuals. Offers mortgages, loans, savings and much more" />

<meta property="og:title" content="Airdrie Savings Bank" />
<meta property="og:description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="cleartype" content="on">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
    <meta name="google-site-verification" content="OQ4xeOxsy4dM-80Atd4ZwxWiS_Ztsd-ykOXMLMT-xCk" />
    <link rel="canonical" href="index.php"/>
    <!--[if lte IE 8 ]>
        <link rel="stylesheet" href="/Content/css/all-old-ie.css" />
        <script>'article|section'.replace(/\w+/g,function(t){document.createElement(t)})</script>
        <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!--[if gt IE 8]><!-->
    <link rel="stylesheet" href="../Content/css/all.css">
    <!--<![endif]-->
    <link rel="shortcut icon" href="../Content/images/icons/favicon.ico" />
    <link rel="apple-touch-icon" href="../Content/images/icons/apple-touch-icon.png" />
    <link rel="apple-touch-icon-precomposed" href="../Content/images/icons/apple-touch-icon.png" />
    <link rel="shortcut icon" href="../Content/images/icons/apple-touch-icon.png">
    <link rel="stylesheet" href="../Content/webfonts/css/fontello.css">
    <link rel="stylesheet" href="../Content/webfonts/css/animation.css">
    <!--[if IE 7]>
        <link rel="stylesheet" href="/Content/css/all-old-ie.css">
        <link rel="stylesheet" href="/Content/webfonts/css/fontello-ie7.css">
    <![endif]-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
    <script src="../Content/js/modernizr.js"></script>
</head>
<body>
    <header class="masthead" role="banner">
        <div class="wrapper">
            <div class="triggers">
                <button class="trigger pull-left js-trigger--nav"><i class="icon-menu mega"></i></button>
                <button class="trigger trigger-border js-trigger--utility"><i class="icon-lock mega"></i></button>
                <button class="trigger js-trigger--search"><i class="icon-search mega"></i></button>
            </div>
            <nav class="nav nav-utility js-panel--utility">
                <ul>
                    <li class="btn-login-panel pull-right-tablet"><a href="https://www.asbolb.com/servlet/ASB.ASBServlet/" target="_blank" class="btn btn-primary btn-login"><i class="icon-lock"></i>Login to internet banking</a></li>
                    <li class="pull-right-tablet visable-on-large"><a href="https://twitter.com/AirdrieSBank" target="_blank"><i class="icon-twitter-circled social-icon"></i> <span class="hide-on-tablet delta">Follow us on Twitter</span></a></li>
                    <!--<li class="pull-right-tablet"><a href="#"><i class="icon-facebook-circled social-icon"></i> <span class="hide-on-tablet delta">Follow us on Facebook</span></a></li>-->
                </ul>
            </nav>
            <div class="wrap-search medium-5 pull-right-tablet js-panel--search">
                <div class="global-search">
                    <form class="search" action="https://airdriesavingsbank.com/search" method="GET">
                        <label>Search the site</label>
                        <input type="text" placeholder="What are you looking for?" name="s" id="s">
                        <button class="btn btn-search" type="submit"><i class="icon-search"></i></button>
                    </form>
                </div>
            </div>
            <!--[if gt IE 8]><!-->
                <a class="site-logo" href="../index.php"><img src="../Content/images/branding/asb-logo.svg" alt="Airdrie Savings Bank"></a>
            <!--<![endif]-->
            <!--[if lte IE 8 ]>
                <a class="site-logo" href="/"><img src="/Content/images/branding/ie-logo.png" alt="Airdrie Savings Bank"></a>            
            <!--<![endif]-->
            <h2 class="tagline">Britain's only Independent Savings Bank <span><i>Est. 1835</i></span></h2>
        </div>
    </header>

    


<nav class="nav nav-primary js-panel--nav" role="navigation">
    <div class="wrapper wrapper-wide">
        <div class="medium-12 block">
            <ul>
                    <li class=" home ">
                        <a href="../index.php" class="active">Home</a>
                    </li>
                    <li class="submenu">
                        <a href="../business/index.php" class="active">Business</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../business/new-idea%2c-new-venture/index.php">New idea, new venture?</a> 
                                    </li>
                                    <li>
                                        <a href="../business/business-bank-accounts/index.php">Business bank accounts</a> 
                                    </li>
                                    <li>
                                        <a href="../business/business-savings-accounts/index.php">Business savings accounts</a> 
                                    </li>
                                    <li>
                                        <a href="../business/business-loans/index.php">Business loans</a> 
                                    </li>
                            </ul>
                    </li>
                    <li class="submenu">
                        <a href="../personal/index.php" class="active">Personal</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../personal/current-account/index.php">Current account</a> 
                                    </li>
                                    <li>
                                        <a href="../personal/savings-accounts/index.php">Savings accounts</a> 
                                    </li>
                                    <li>
                                        <a href="../personal/loans/index.php">Loans</a> 
                                    </li>
                                    <li>
                                        <a href="../personal/mortgages-and-bridging-loans/index.php">Mortgages and bridging loans</a> 
                                    </li>
                                    <li>
                                        <a href="../personal/buy-to-let-mortgage/index.php">Buy To Let Mortgage</a> 
                                    </li>
                            </ul>
                    </li>
                    <li class="submenu">
                        <a href="../third-sector/index.php" class="active">Third Sector</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../third-sector/what-sets-us-apart/index.php">What sets us apart?</a> 
                                    </li>
                                    <li>
                                        <a href="../third-sector/social-enterprise-lending/index.php">Social enterprise lending</a> 
                                    </li>
                                    <li>
                                        <a href="../third-sector/social-enterprise-savings/index.php">Social enterprise savings</a> 
                                    </li>
                                    <li>
                                        <a href="../third-sector/social-mortgage/index.php">Social: Mortgage</a> 
                                    </li>
                            </ul>
                    </li>
                    <li class="submenu">
                        <a href="../under-18s/index.php" class="active">Under 18s</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../under-18s/independent-account/index.php">Independent account</a> 
                                    </li>
                                    <li>
                                        <a href="../under-18s/saving-with-asb/index.php">Saving with ASB</a> 
                                    </li>
                            </ul>
                    </li>
                    <li class="submenu">
                        <a href="../our-ethos/index.php" class="active">Our ethos</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../our-ethos/history/index.php">History</a> 
                                    </li>
                                    <li>
                                        <a href="../our-ethos/financial-information/index.php">Financial information</a> 
                                    </li>
                                    <li>
                                        <a href="../our-ethos/governance/index.php">Governance</a> 
                                    </li>
                                    <li>
                                        <a href="../our-ethos/regulation/index.php">Regulation</a> 
                                    </li>
                            </ul>
                    </li>
                    <li class="">
                        <a href="../intermediaries/index.php" class="active">Intermediaries</a>
                    </li>
                    <li class="">
                        <a href="../partners/index.php" class="active">Partners</a>
                    </li>
                    <li class="submenu">
                        <a href="../get-in-touch/index.php" class="active">Get in touch</a>
                            <span class="expander"><i class="icon-down-open-1 beta"></i></span>
                            <ul>
                                    <li>
                                        <a href="../get-in-touch/locations/index.php">Locations</a> 
                                    </li>
                            </ul>
                    </li>
            </ul>
        </div>
    </div>
</nav>

    


<div class="wrapper">
    <div class="content editor-content" role="main">

        

<nav class="nav medium-12 nav-breadcrumbs margin-btm-med margin-top-med">
    <ol>
            <li><a href="../index.php" title="Home">Home</a></li>
        <li>Disclosure Personal Information Statements</li>
    </ol>
</nav>


        



<div class="medium-3">
    <ul class="nav-secondary">
    </ul>
</div>

        <div class="medium-9 relative">
            <header class="header-border">
                <h1 class="tera">Disclosure and Use of Personal Information Statements</h1>
                <p class="alpha"></p>
            </header>

            <div class="row">
                <div class="cf margin-btm-large">
                    <div class="medium-12 large-12">
                        <p><strong>Who we are</strong></p>
<p>Airdrie Savings Bank was instituted in 1835 under the Savings Bank (Scotland) Act 1819 and has its Head Office at 56 Stirling Street, Airdrie ML6 0AW.  The main business of the Bank is providing banking services. We are authorised by the Prudential Regulation Authority and  regulated by the Financial Conduct Authority and  the Prudential Regulation Authority. Our firm’s reference number is 204584. We subscribe to the Lending Code and are licensed under the Consumer Credit Act by the Office of Fair Trading under licence number 020348.</p>
<p><i> </i></p>
<p><strong>Where we obtain your information</strong></p>
<p>Apart from the information you give to us [or our agents], we may collect information about you from:</p>
<ul class='lister margin-btm-xlarge'>
<li>other account holders you are connected with;</li>
<li>credit reference agencies (see below);</li>
<li>other organisations, including fraud prevention agencies; and</li>
<li>any joint applicant, if you have given them permission to disclose information to us for a joint account application.</li>
</ul>
<p> </p>
<p><strong>How we use your information and who we share it with</strong></p>
<p><strong>Fraud prevention</strong></p>
<p>We may check your information with fraud prevention agencies.  If false or inaccurate information is provided and fraud is identified, details will be passed to fraud prevention agencies. Law enforcement agencies may access and use this information. We and other organisations may also access and use this information to prevent fraud and money laundering, for example, when:</p>
<ul class='lister margin-btm-xlarge'>
<li>checking details on applications for credit and credit related or other facilities;</li>
<li>managing credit and credit related accounts or facilities;</li>
<li>recovering debt;</li>
<li>checking details on proposals and claims for all types of insurance, or checking details of job applicants and employees</li>
</ul>
<p>We and other organisations may access and use the information recorded by fraud prevention agencies from other countries.</p>
<p><i> </i></p>
<p><strong>Credit reference agencies</strong></p>
<p>In order to assess any application that you may make for credit products, or any request for an increase to any existing credit product that we may already provide to you, or to provide you with credit products and services, we will search the records of one or more licensed credit reference agencies to obtain information on you. These agencies may add details of our search and your application to the records they hold on you, whether or not your application proceeds, We may also add details of how your agreement or accounts operate with us to these records, including any defaults or failure to keep to the terms of your agreement and/or any failure to advise us of a change of address where a payment is overdue. Credit searches and other information provided to the credit reference agencies and fraud prevention agencies about you, and those with whom you are linked financially, may be used and disclosed by such agencies to other companies unrelated to us for the purposes mentioned above. Credit reference agencies will also use the information for statistical analysis about credit, insurance, and fraud.</p>
<p>When submitting a loan application you agree that we may use the information supplied in this application for credit assessment, including searching files of a Credit Reference Agency, which will keep a record whether or not credit is granted. In addition, transactional information relating to the conduct of the Agreement if granted will be disclosed periodically to the Credit Reference Agencies for the purpose of making future credit decisions, fraud prevention or tracing debtors.</p>
<p> </p>
<p><strong>Links and association</strong></p>
<p>For the purposes of this application you may be treated as financially linked and your application will be assessed with reference to any “associated” records. An “association” between joint applicants and/or any individual identified as your financial partner will be created at credit reference agencies which will link your financial records. You and anyone else with whom you have a financial link understand that each other’s information will be taken into account in all future applications by either or both of you. This linking will continue until one of you successfully files a “disassociation” at the credit reference agencies. Information held about you by the credit reference agencies may already be linked to records relating to one or more of your partners.</p>
<p> </p>
<p><strong>Other sharing of information</strong></p>
<p>We may also share your information with our agents and service providers who provide a service to us and you;</p>
<p>We will not pass your information to anyone outside Airdrie Savings Bank other than for the purposes described above, unless:</p>
<ul class='lister margin-btm-xlarge'>
<li>we have to give the information by law;</li>
<li>there is a duty to the public to make the information known;</li>
<li>our interests mean we must give the information (for example, to prevent fraud); or</li>
<li>we have your permission.</li>
</ul>
<p> </p>
<p><strong>Lending decisions</strong></p>
<p>Where a lending decision is involved, the information will aid us in assessing the extent of the credit we may be prepared to offer to you.  Credit scoring (an automated method for assisting with decision making) may be used for credit assessment. We will inform you in writing if your application is declined.</p>
<p><i> </i></p>
<p><strong>Keeping you informed</strong></p>
<p>If you have given your permission either below or separately, we may occasionally want to tell you about Airdrie Savings Bank's other products and services which may be of interest.  If you have agreed, this could be by letter, phone (including text messages) or email.</p>
<p> </p>
<p><strong>Your rights</strong></p>
<ul class='lister margin-btm-xlarge'>
<li>You have a right to receive a copy of the information we hold about you if you apply in writing.  You may need to pay a fee. </li>
<li>You have a right to stop us contacting you for direct marketing purposes.  You may contact us at any time in the future if you want us to stop.  However, choosing not to receive marketing information from us will mean that you will not receive details about any of our special offers and promotions.</li>
<li>You have a right to receive details of the fraud prevention agencies and credit reference agencies we get information from and record information about you. Please request this information by writing to us at our Head Office, 56 Stirling Street, Airdrie, ML6 0AW.</li>
<li>If you have any questions about how we use your personal information, please write to us or phone us or, contact a branch.</li>
</ul>
                    </div>
                </div>
            </div>
            
                         
            <div class="row">
            </div>
            

        </div>
    </div>
</div>

    <div class="bg-light-blue editor-content subfooter">
        <div class="wrapper">
            <div class="content" role="main">
                <div class="medium-4 margin-top-xlarge margin-btm-xlarge">
                    <div class="row row-small">
                        <div class="small-3 medium-4">
                            <!--[if gt IE 8]><!-->
                            <img class="img-width" src="../Content/images/icons/icon-loan-calculator.svg" alt="" />
                            <!--<![endif]-->
                            <!--[if lte IE 8 ]>
                                <img src="/Content/images/icons/ie-icon-loan-calculator.png" alt="" />
                            <!--<![endif]-->                            
                        </div>
                        <div class="small-9 medium-8">
                            <h3 class="alpha">Loan calculator</h3>
                            <p class="gamma">Find out how competitive a loan from Airdrie Savings Bank can be.</p>
                            <a href="../personal/loans/loan-calculators/index.php" class="gamma"><i class="icon-right-circle"></i> <strong>Use our loan calculator</strong></a>
                        </div>
                    </div>
                </div>
                <div class="medium-4 margin-top-xlarge margin-btm-xlarge">
                    <div class="row row-small">
                        <div class="small-3 medium-4">
                            <!--[if gt IE 8]><!-->
                            <img class="img-width" src="../Content/images/icons/icon-mortgage-calculator.svg" alt="" />
                            <!--<![endif]-->
                            <!--[if lte IE 8 ]>
                                <img src="/Content/images/icons/ie-icon-mortgage-calculator.png" alt="" />
                            <!--<![endif]-->
                        </div>
                        <div class="small-9 medium-8">
                            <h3 class="alpha">Mortgage calculator</h3>
                            <p class="gamma">Find out how much you can borrow, and get a no-obligation personalised quotation.</p>
                            <a href="../personal/mortgages-and-bridging-loans/mortgage-calculator/index.php" class="gamma"><i class="icon-right-circle"></i> <strong>Use our mortgage calculator</strong></a>
                        </div>
                    </div>
                </div>
                <div class="medium-4 margin-top-xlarge margin-btm-xlarge">
                    <div class="row row-small">
                        <div class="small-3 medium-4">
                            <!--[if gt IE 8]><!-->
                            <img class="img-width" src="../Content/images/icons/icon-lost-card.svg" alt="" />
                            <!--<![endif]-->
                            <!--[if lte IE 8 ]>
                                <img src="/Content/images/icons/ie-icon-lost-card.png" alt="" />
                            <!--<![endif]-->                                
                        </div>
                        <div class="small-9 medium-8">
                            <h3 class="alpha">Lost or stolen card or PIN?</h3>
                            <p class="gamma">Let us know as soon as possible.</p>
                            <a href="../lost-or-stolen-card-or-pin/index.php" class="gamma"><i class="icon-right-circle"></i> <strong>Find out what you should do here</strong></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer" role="contentinfo">
        <div class="wrapper">
            <div class="medium-8">
                <div class="row row-small">
                    <div class="small-12 medium-4">
                        <a class="site-logo site-logo-footer" href="../index.php">
                            <!--[if gt IE 8]><!-->
                                <img class="hide-on-mobile" src="../Content/images/branding/asb-logo.svg" alt="Airdrie Savings Bank" />
                            <!--<![endif]-->
                            <!--[if lte IE 8 ]>
                                <img class="hide-on-mobile" src="/Content/images/branding/ie-logo.png" alt="Airdrie Savings Bank" />
                            <!--<![endif]-->                                                            
                        </a>
                    </div>
                    <div class="small-12 medium-3">
                        <ul class="lister lister-footer">
                            <li>Head office:</li>
                            <li>56 Stirling Street</li>
                            <li>Airdrie</li>
                            <li>Scotland</li>
                            <li>ML6 0AW</li>
                        </ul>
                    </div>
                    <div class="small-12 medium-5">
                        <ul class="lister lister-footer lister-footer-alt">
                            <li><strong></strong> </li>
                            <li><strong>Email:</strong> <a href="mailto:infodesk@classicsmake.com">infodesk@classicsmake.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="medium-4 relative">
                <div class="site-footer-bar"></div>
                <ul class="lister lister-footer lister-footer-deep two-up">
                    <li class="col"><a href="../index.php"><i>Home</i></a></li>
                    
                        <li class="col"><a href="../call-back/index.php"><i>Call-back</i></a></li>
                        <li class="col"><a href="../personal/index.php"><i>Personal</i></a></li>
                        <li class="col"><a href="../accessibility/index.php"><i>Accessibility</i></a></li>
                        <li class="col"><a href="../business/index.php"><i>Business</i></a></li>
                        <li class="col"><a href="index.php"><i>Privacy policy</i></a></li>
                        <li class="col"><a href="../under-18s/index.php"><i>Under 18s</i></a></li>
                        <li class="col"><a href="../terms-conditions/index.php"><i>Terms and conditions</i></a></li>
                        <li class="col"><a href="../our-ethos/index.php"><i>Our ethos</i></a></li>
                        <li class="col"><a href="../internet-banking/staying-secure/index.php"><i>Staying secure</i></a></li>
                </ul>
            </div>
            <div class="medium-12">
                <div class="row">
                    <div class="small-12 medium-6">
                        <p class="delta margin-top-large margin-btm-xlarge"><i>Airdrie Savings Bank is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. <br />Our firm reference number is 204584.</i></p>
                    </div>
                    <div class="small-12 medium-6">
                        <a class="pull-right push--left push-half--top" href="../media/52589/FSCS-Booklet.pdf">
                            <img src="../Content/images/branding/fscs.jpg" width="100" alt="Financial Services Compensation Scheme" />
                        </a>
                        <div class="pull-right push-half--top" style="background: #fff; padding: 0 10px;">
                            <script type="text/javascript" src="https://seal.verisign.com/getseal?host_name=airdriesavingsbank.com&amp;size=L&amp;use_flash=NO&amp;use_transparent=NO&amp;lang=en"></script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="../../ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script src="../Content/js/jquery-ui.js"></script>
    <script src="../Content/js/jquery.ui.touch-punch.min.js"></script>
    <script src="../Content/js/foundation.reveal.js"></script>
    <script src="../Content/js/responsiveslides.min.js"></script>
    <script src="../Content/js/easyResponsiveTabs.js"></script>
    <script src="../Content/js/scripts.js"></script>

    <script src="../app/scripts/angular.min.js"></script>
    <script src="../app/scripts/slider.js"></script>
    <script src="../app/app.js"></script>
    <script src="../app/loanController.js"></script>
    <script src="../app/expressLoanController.js"></script>
    <script src="../app/loanService.js"></script>
    
    <!--Google-->
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date(); a = s.createElement(o),
            m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '../../www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-48958610-1', 'airdriesavingsbank.com');
        ga('send', 'pageview');

    </script>
    <!--Google-->
    
    <script type="text/javascript" src="../Content/js/cookie.js"></script>
    <script type="text/javascript">
        $.stormCookie({
            cookiePageUrl: 'https://airdriesavingsbank.com/cookies/',
            target: '_blank'
        });
  </script>

</body>

<!-- Mirrored from airdriesavingsbank.com/disclosure-personal-information-statements/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 09 Jul 2016 12:02:16 GMT -->
</html>
