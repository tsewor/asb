<?php 
$host = 'localhost';
$user = 'Despotech';
$pass = '1nigeria';
$db   = 'asb';
$con = mysql_connect($host, $user, $pass);
$set_data = mysql_select_db($db);
if(mysql_error())
{
	echo 'There was error connecting to database';
	die();
}
?>