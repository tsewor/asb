<HTML>
<!-- Created by HTTrack Website Copier/3.48-22 [XR&CO'2014] -->

<!-- Mirrored from airdriesavingsbank.com/intermediaries/ifa-login/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 09 Jul 2016 12:03:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html;charset=UTF-8"><META HTTP-EQUIV="Refresh" CONTENT="0; URL=../intermediary-login/index.php"><TITLE>Page has moved</TITLE>
</HEAD>
<BODY>
<A HREF="../intermediary-login/index.php"><h3>Click here...</h3></A>
</BODY>
<!-- Created by HTTrack Website Copier/3.48-22 [XR&CO'2014] -->

<!-- Mirrored from airdriesavingsbank.com/intermediaries/ifa-login/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 09 Jul 2016 12:03:52 GMT -->
</HTML>
